package edu.stanford.crypto.cs251.miners;

import org.apache.commons.math3.distribution.ExponentialDistribution;
import org.junit.Test;

/**
 * Created by bbuenz on 08.10.15.
 */
public class PlayGround {
    @Test
    public void playGround() {

    }
}
